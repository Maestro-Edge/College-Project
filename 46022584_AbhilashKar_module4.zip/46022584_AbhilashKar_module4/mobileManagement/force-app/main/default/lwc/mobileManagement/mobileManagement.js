import { LightningElement, wire,track } from 'lwc';
import getAllMobiles from "@salesforce/apex/mobileManage.getAllMobiles";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

export default class MobileManagement extends LightningElement {

    @track mobiles;
    @wire(getAllMobiles) mobiles;
    handleAccountCreated(event){

        //after the mobile record is created it's id
        const id=event.target.value;

        //success message to show the record has been inserted
        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Mobile record is created',
            variant: 'success',
        });
        this.dispatchEvent(evt);
        //window.location.reload();

        //refresh the list
        return refreshApex(this.mobiles);
        
        
    }
    
}